for index, character in enumerate("abcdefgh"):
    print(index, character)
